import express from "express";
import multer from "multer";
import { validateCsrfToken, requireAuth, requireAdmin } from "../middleware/authMiddleware.js"; 

// Separação de domínios em controllers distintos
import UserController from "../controllers/userControllers.js";
import BannerControllers from "../controllers/bannerControllers.js";

const userController = new UserController();
const bannerController = new BannerControllers();
const upload = multer({ storage: multer.memoryStorage() });

const router = express.Router();

router.post("/login", validateCsrfToken, (req, res, next) => userController.login(req, res, next));
router.post("/register", validateCsrfToken, (req, res, next) => userController.register(req, res, next));
router.post("/forgotPassword", validateCsrfToken, (req, res, next) => userController.forgotPassword(req, res, next));
router.post("/PasswordReset", validateCsrfToken, (req, res, next) => userController.PasswordReset(req, res, next));

router.post("/updatePassword", requireAuth, validateCsrfToken, (req, res, next) => userController.updatePassword(req, res, next));

router.post("/verify-otp", validateCsrfToken, (req, res, next) => userController.verifyOtp(req, res, next));
router.post("/email/send-otp", requireAuth, validateCsrfToken, (req, res, next) => userController.sendEmailOtp(req, res, next));
router.post("/phone/send-otp", requireAuth, validateCsrfToken, (req, res, next) => userController.sendPhoneOtp(req, res, next));
router.post("/phone/verify-otp", requireAuth, validateCsrfToken, (req, res, next) => userController.verifyPhoneOtp(req, res, next));

router.post("/deleteUser/:id", requireAuth, requireAdmin, validateCsrfToken, (req, res, next) => userController.deleteUser(req, res, next));
router.post("/updateProfile", requireAuth, validateCsrfToken, (req, res, next) => userController.updateProfile(req, res, next));

router.post(
    "/users/edit/:id",
    requireAuth,
    requireAdmin,
    validateCsrfToken,
    (req, res, next) => userController.updateUser(req, res, next)
);
router.delete(
    "/users/edit/:id",
    requireAuth,
    requireAdmin,
    validateCsrfToken,
    (req, res, next) => userController.deleteUser(req, res, next)
);

router.post(
    "/updateBannerHome",
    requireAuth,
    requireAdmin,
    upload.single("bannerImage"),
    validateCsrfToken,
    (req, res, next) => bannerController.updateBannerHome(req, res, next)
);

router.post(
    "/updateCategoryHome",
    requireAuth,
    requireAdmin,
    upload.single("categoryImage"),
    validateCsrfToken,
    (req, res, next) => bannerController.updateCategoryHome(req, res, next)
);

router.post(
    "/deleteCategoryHome/:id",
    requireAuth,
    requireAdmin,
    validateCsrfToken,
    (req, res, next) => bannerController.deleteCategoryHome(req, res, next)
);

export default router;